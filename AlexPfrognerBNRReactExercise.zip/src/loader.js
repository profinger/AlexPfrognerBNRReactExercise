//import axios so we can use it to retrieve data with promises
import axios from 'axios'; 

export function load(url) {
    //return the promise that axios creates so we can have functionality
    // that waits for it to resolve and also handle errors
	  return axios.get(url);
}
