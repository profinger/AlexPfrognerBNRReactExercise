import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import {Blog} from './blog.js';

//This is the correct call with the correct url.  It causes the <Blog /> tag to get rendered to the page
ReactDOM.render(<Blog url="https://jsonplaceholder.typicode.com/posts" />, document.getElementById('root'));

//Uncomment this to test error state since I didn't have time to figure out the unit test
//ReactDOM.render(<Blog url="https://BROKENjsonplaceholder.typicode.com/posts" />, document.getElementById('root'));

