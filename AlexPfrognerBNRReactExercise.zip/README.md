This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

Run 'npm install' to install the appropriate required dependencies

Most of the files in the 'public' folder weren't modified.

Description of files in 'src':

- blog.js: This is the file that holds all of the React components used to create the blog.
- index.css: Styling
- index.js: Javascript file used to initiate ReactDOM rendering
- index.test.js: The unit test file.  It is more empty than I'd have liked
- loader.js: holds the loading function that uses axios to load the data



******* Debrief *******
Coming into this exercise I was learning React, Redux, unit testing, jest, and (for the most part) asynchronous patterns.  

For React, I was able to pick up it pretty quickly and felt pretty comfortable with it and wrote most of the blog code in about an hour and a half after following the official tutorial.  When following a tutorial, I tend to test my understanding and assumptions about how things might relate back to languages that I'm more familiar with by changing variable names or by slightly modifying how a call might be made or a method might be engineered.  This allows me quick feedback to see if I'm correct or not and allows me to quickly identify spots that are required (using the name props for the props property) and other spots that are just convention within the tutorial (naming the props parameter in a constructor props).  It also allows me to more deeply explore my understanding of the limitations of a certain portion of functionality.  I might try to shove way too much logic into {} braces to make sure I'm correct in assuming that won't break the component.

For Redux, I was having trouble understanding exactly how it would be useful in this application or why you might use Redux.  Given more time I'd have done more reading on it and would've loved to attempt to implement it into my exercise.

For unit testing, I spoke with several friends and colleagues about it.  I hadn't done it before personally and didn't fully understand the application for it but after discussing with my peers I was able to realize some of the value behind unit tests (allowing you to quickly test several scenarios instead of having to go through the UI and checking that functionality still works as expected even after a lot of refactoring).  I still have a little difficulty understanding to what degree things need tested but I believe that, for this exercise, it was especially difficult as there wasn't a lot of user interaction happening.  
	Ultimately, my biggest limits in unit testing with this project were:
		- Figuring out things that made sense to test
		- Understanding how to go about implementing tests for them within React

For asynchronous patterns, I didn't realize until I got to unit testing how rusty I was with this technology.  Given more time I'd dive deeper in to these but in my career I haven't had a lot of interaction with them so I'm mostly unfamiliar with them.


******* Conclusion *******
I was excited to learn React and I feel like it became familiar to me pretty quickly.  The concepts felt loosely similar to AngularJS (which I work a great deal with) and I felt that I could easily translate a lot of my common patterns to this kind of workflow.

There was a lot to learn in this exercise that I wasn't really expecting and it made for quite a challenge.  Given more time I would've loved to spend more time diving into Redux and unit testing but I ran out of time while trying to include everything listed in the exercise. 

Thank you for the opportunity to work on this.  I hope we are able to work together!
