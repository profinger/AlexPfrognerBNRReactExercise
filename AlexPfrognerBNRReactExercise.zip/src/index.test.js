import { load } from './loader.js';
import { Blog } from './blog.js';
import React from 'react';
import renderer from 'react-test-renderer';
import ReactTestUtils from 'react-dom/test-utils';

describe('React loader Tests', () => {
	//Test the blog object
	describe('Blog', () => {
		test.todo('Test for error state by filling incorrect url into blog');
		test.todo('Test for successful rendering if the url is correct');

		// I tried a few things with the below but and was researching but ran out of time.
		//it('shows error message if url is incorrect', () => {
		//	const b = renderer.create(<Blog url="https://brokenjsonplaceholder.typicode.com/posts"/> )
		//	
		//	expect(b).toContain('<div>Sorry.  Data could not be loaded from the specified server.</div>');
		//}); 
	});

	//Test the loader 
	describe('Loader Object', () => {
		it('should load data', () => {
			//call load from loader with the appropriate url
			load('https://jsonplaceholder.typicode.com/posts').then(function (resp) { 
				//if resp has any results then we know it loaded data that we were expecting
				expect(resp).any();
			});
		});
	});
});