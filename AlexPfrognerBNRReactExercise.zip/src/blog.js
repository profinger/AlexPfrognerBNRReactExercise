import React from 'react';

//import our load function from our loader js file that uses axios to load the posts
import { load } from './loader.js';

//define the Post component as a function.  This is what displays the posts to the page.
function Post(props) {
	//return the appropriate html to show the post and pass the onClick event that
	// came from the parent on to each object
	return (
		<div className="post" onClick={props.onClick}>
		<h2>{props.title}</h2>
		<h6>{props.userid}</h6>
		<p>{props.body}</p>
		</div>
		);
}

//This is the Col column component.  It was mostly made so I could avoid duplicating 
// the functions that actually build the post groupings out.  
class Col extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
		}
	}

	//createPosts uses the list of posts that was set on the props to build out the 
	// appropriate list of <Post /> components with their props set accordingly
	createPosts = () => {
		let grp = [];

		const psts = this.props.posts;

		//We loop through each post appending new <Post/> components to the group so they
		// can be rendered
		for (let i = 0; i < psts.length; i++) {
			const uId = psts[i].userId;
			grp.push(<Post key={i} 
							userid={psts[i].userId} 
							title={psts[i].title} 
							body={psts[i].body}
							//The uId is passed here so that we can do the cool 
							// "reassign current user on click" functionality
							onClick={(i)=>this.props.onClick(uId)}
						/>)
		}

		//return so it can be rendered
		return grp;
	}

	render () {
		//return the column object with a title (specified in props) and the group of 
		// <Post/> objects created above
		return (
			<div className="column">
				<h1>{this.props.title}</h1>
				{this.createPosts()}
			</div>
			)
	}
}

//The Blog class is the parent object.  It renders the Col objects and holds all the info
// as well as taking in a url prop which is the source of our posts.
export class Blog extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			myPosts: [],
			allPosts: [],
			otherPosts: [],
			userId: 1,
			loadedSuccessful: false,
			currentlyLoading: true,
		}
	}

	//This is called once the component is mounted.  My understanding is it's basically
	// equivalent to the C# Form Load.  We use it here to load data so that we don't have
	// other stuff waiting on it.
	componentDidMount() {
		//start loading from the url specified in the prop
		load(this.props.url)
		//once the load is done..
		.then(result => {
	      let posts = result.data;
	      const user = this.state.userId;

	      //Get posts for the current user "user"
	      let curUserPosts = posts.filter(function (p) { return p.userId === user; })

	      //Get posts for all other users
	      let otherPosts = posts.filter(function (p) { return p.userId !== user; })

	      //Set the state of the Blog object so all of the data is available
	      this.setState({myPosts: curUserPosts, 
	      				allPosts: posts, // we pass this so we don't have to keep loading posts
	      				otherPosts: otherPosts, 
	      				loadedSuccessfuly: true, 
	      				currentlyLoading: false
	      			});
	    })
		//an error was thrown.  We set the loadedSuccessfuly and currentlyLoading flags
		// to indicated that the page didn't load correctly so the page knows to display 
		// an error state
	    .catch(err=> { this.setState({loadedSuccessfuly: false, currentlyLoading: false }); });
	}

	//This function is called on click of a blog post.  It causes a new user to become current
	loadNewUser (userId) {
		const posts = this.state.allPosts.slice();

		//again we filter all of the posts to separate them based on the current user
		let curUserPosts = posts.filter(function (p) { return p.userId === userId; })
		let otherPosts = posts.filter(function (p) { return p.userId !== userId; })

		//Filter our posts based on current user. I'm not worried about setting the loading statuses 
		// here since we aren't retrieving data again just filtering it
		this.setState({userId: userId, myPosts: curUserPosts, otherPosts: otherPosts});
	}


	render() {
		if (!this.state.currentlyLoading) { //if the data isn't currently loading
			if (this.state.loadedSuccessfuly) { //and if the data loaded successfully
				//Display the data!
				return ( 
				<div>
					<Col posts={this.state.myPosts} title={"User " + this.state.userId + "'s Posts"} userId={this.state.userId} onClick={(userId)=>this.loadNewUser(userId)}/>
					<Col posts={this.state.otherPosts} title={"Other's Posts"} onClick={(userId)=>this.loadNewUser(userId)}/>
					
				</div>
				)
			} else { //If the data didn't load successfully.. Give them an error :-(
				return (
				<div>Sorry.  Data could not be loaded from the specified server.</div>
				)
			}
		//in case it takes a while to load the data (or just for the split second flash)
		// show them a loading state
		} else { 
			return (
				<div>Loading... please wait.</div>
			)
		}
	}
}